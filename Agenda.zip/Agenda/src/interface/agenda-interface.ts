//criação de uma estrutura de dados (antigo registro)
export interface IPessoa {
    id: number;
    nome: string;
    telefone: string;
    endereco: string;
}