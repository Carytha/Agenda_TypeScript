import { AgendaService } from "../service/agenda-service";
import { Request,Response }  from "express";

//crio uma propriedade na classe referenciando a classe que eu desejo usar
export class AgendaController {
    private agendaService: AgendaService;

    constructor() {
        this.agendaService = new AgendaService();
    }

    public async criar(req: Request, res: Response) {
        //estou perguntando se o req.body(onde virá o conteúdo) está vazio
        if (Object.keys(req.body). length ===0) {
            res.status(400).json({message: "O corpo da requisição está vazio"});
            return;
        }
        try{
            //o http só tem acesso ao service através do controler, aí sim ele cria um novo registro na agenda
            await this.agendaService.criar(req.body); //req é uma classe, .body é uma propriedade dessa classe
            res.status(201).json({message: 'Item criado com sucesso'});
        } catch (erro:any){
            res.status(500).json({message: erro.message});
        }
    }
}