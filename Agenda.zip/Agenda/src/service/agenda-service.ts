
//export porque poderei usar esta classe em outras classes
export class AgendaService {
    private agendaModel: AgendaModel; //propriedade para fazer conexão com a classe que eu quero usar

    constructor() {
        this.agendaModel = new AgendaModel(); //instancio agendaModel
    }

    /* public async criar(nome: string, telefone: string, endereco:string) // async para eu não esperar a resposta na mesma hora
        {
            
    } */

    public async criar(pessoa:IPessoa) {
        //preciso usar o try para pegar possíveis erros
        try {
            //toda função assincrona precisa do await 
            await AgendaModel.create({
                id: pessoa.id,
                nome: pessoa.nome,
                telefone: pessoa.telefone,
                endereco: pessoa.endereco
            })
            
        } catch (erro:any) {
            throw new Error (erro.message);
        }
        //catch é pegar, se não consiguer, pegue este erro.
    }

    //
    public async listarTodas () {
        try {
            const pessoas: AgendaModel[] = await AgendaModel.findAll();
            return pessoas;
        }catch (erro:any) {
            throw new Error(erro.message);
        }
    }

    //chave tiver Maria, vai buscar somente por Maria
    public async listarPorNome(chave:string) {
        const filtro = {
            where: {
                nome: chave,
            }
        }
        try {
            const pessoas: AgendaModel[] = await AgendaModel.findAll(filtro);
            return pessoas;
        }catch (erro:any) {
            throw nes Error(erro.message);
        }
    }

    //
    public async alterar (id:number, item: IPessoa) {
        try {
            const pessoa: any = await AgendaModel | null = await AgendaModel.findByPK(id);
            if(pessoa) {
                pessoa.nome = item.nome;
                pessoa.telefone = item.telefone;
                pessoa.endereco = item.endereco;
                pessoa.save;
            } catch (erro:any) {
                throw new Error(erro.message);
            }

        }
    }

    //
    public async excluir(id: number) {
        try {
            const pessoa: AgendaModel | null = await AgendaModel.findByPk(id);
            if (pessoa) {
                pessoa.destroy();
            }catch (erro:any) {
                throw new Error(erro.message);
            }
        }
    }
    
}