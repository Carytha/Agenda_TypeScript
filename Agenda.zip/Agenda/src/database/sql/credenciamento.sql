-- financeiro.tbl_credenciamento definition

CREATE TABLE `tbl_credenciamento` (
  `id_banco` int unsigned NOT NULL,
  `id_atm` int unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;